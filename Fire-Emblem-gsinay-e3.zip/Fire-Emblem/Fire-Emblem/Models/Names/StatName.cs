namespace Fire_Emblem.Models.Names;

public enum StatName
{
    Hp,
    MaxHp,
    Atk,
    Spd,
    Def,
    Res
}