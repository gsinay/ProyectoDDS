namespace Fire_Emblem.Models.Names;

public enum WeaponName
{
    Bow,
    Axe,
    Sword,
    Lance,
    Magic,
    None
}