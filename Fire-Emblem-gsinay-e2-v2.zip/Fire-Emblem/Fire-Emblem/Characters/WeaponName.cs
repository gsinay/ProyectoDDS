namespace Fire_Emblem.Characters;

public enum WeaponName
{
    Bow,
    Axe,
    Sword,
    Lance,
    Magic,
    None
}