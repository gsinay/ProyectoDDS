namespace Fire_Emblem.Characters;

public enum StatName
{
    Hp,
    MaxHp,
    Atk,
    Spd,
    Def,
    Res
}